"""
ml_persistence_v37.py — MetanoSRGAN Elite v3.7
Análisis ML de persistencia de fugas: predicción de reincidencia usando
scikit-learn con datos históricos reales del event_master_table.

Modelos implementados:
  - RandomForest para clasificación de reincidencia (score ≥ 80 en próximos 7 días)
  - GradientBoosting para regresión de elite_score futuro
  - Clustering KMeans para agrupación de activos por patrón de fuga

Entradas reales:
  - event_master_table.json (historial de detecciones)
  - Datos meteorológicos Open-Meteo (viento, temperatura)
  - Datos Sentinel-5P (CH4 ppb, anomalía)

Salidas:
  - Predicción de reincidencia por activo (probabilidad 0-1)
  - Score de riesgo futuro estimado
  - Cluster de comportamiento del activo
  - Recomendaciones de intervención prioritaria
"""

import os
import json
import logging
import numpy as np
from datetime import datetime, timezone, timedelta
from typing import Dict, List, Optional, Tuple
from pathlib import Path
from collections import defaultdict

logger = logging.getLogger(__name__)

# ─── Verificar scikit-learn ───────────────────────────────────────────────────
try:
    from sklearn.ensemble import RandomForestClassifier, GradientBoostingRegressor
    from sklearn.cluster import KMeans
    from sklearn.preprocessing import StandardScaler
    from sklearn.model_selection import cross_val_score
    from sklearn.metrics import classification_report
    import joblib
    _SKLEARN_AVAILABLE = True
except ImportError:
    _SKLEARN_AVAILABLE = False
    logger.warning("scikit-learn no disponible — usando análisis estadístico básico")

# ─── Constantes ───────────────────────────────────────────────────────────────
ELITE_THRESHOLD = 80          # Umbral para alerta ÉLITE
REINCIDENCE_DAYS = 7          # Ventana de predicción de reincidencia
MIN_EVENTS_FOR_ML = 3         # Mínimo de eventos por activo para ML
CH4_BACKGROUND_PPB = 1920.0   # Fondo global NOAA 2024

# Activos monitoreados (Magdalena Medio)
ACTIVOS = [
    "Barrancabermeja", "Galán", "Norean", "Payoa", "Casabe",
    "Miraflores", "Mariquita", "La Dorada", "Puerto Boyacá", "Tibú"
]


class MLPersistenceAnalyzer:
    """
    Analizador ML de persistencia de fugas de metano.
    Usa datos históricos reales para predecir reincidencia y priorizar intervenciones.
    """

    def __init__(
        self,
        data_dir: str = "/home/ubuntu/metanosrgan_v37/data",
        models_dir: str = "/home/ubuntu/metanosrgan_v37/data/ml_models",
    ):
        self.data_dir = data_dir
        self.models_dir = models_dir
        os.makedirs(models_dir, exist_ok=True)

        self.scaler = StandardScaler() if _SKLEARN_AVAILABLE else None
        self.rf_classifier = None
        self.gb_regressor = None
        self.kmeans = None
        self._trained = False

        # Cargar historial
        self.events = self._load_events()
        logger.info(
            f"MLPersistenceAnalyzer inicializado — "
            f"sklearn: {'OK' if _SKLEARN_AVAILABLE else 'N/A'} | "
            f"Eventos históricos: {len(self.events)}"
        )

    def _load_events(self) -> List[Dict]:
        """Carga el historial de eventos del event_master_table.json."""
        path = os.path.join(self.data_dir, "event_master_table.json")
        if os.path.exists(path):
            try:
                with open(path, "r") as f:
                    data = json.load(f)
                    if isinstance(data, list):
                        return data
                    elif isinstance(data, dict) and "events" in data:
                        return data["events"]
            except Exception as e:
                logger.warning(f"Error cargando eventos: {e}")
        return []

    def _extract_features(self, event: Dict) -> List[float]:
        """
        Extrae features numéricas de un evento para el modelo ML.
        Features:
          [0] ch4_ppb_anomaly — anomalía de CH4 sobre el fondo
          [1] wind_speed — velocidad del viento (m/s)
          [2] wind_deg_sin — componente seno de la dirección del viento
          [3] wind_deg_cos — componente coseno de la dirección del viento
          [4] persistencia_dias — días consecutivos de detección
          [5] hora_deteccion — hora del día (0-23)
          [6] mes_deteccion — mes del año (1-12)
          [7] elite_score — score de élite actual
          [8] flujo_kgh — flujo estimado en kg/h
          [9] perdida_usd — pérdida económica USD/día
        """
        ch4_ppb = event.get("intensidad_ppb", event.get("ch4_ppb_total", CH4_BACKGROUND_PPB))
        anomaly = event.get("ch4_ppb_anomaly", max(0, (ch4_ppb or 0) - CH4_BACKGROUND_PPB))
        wind_speed = event.get("viento_dominante_velocidad", event.get("wind_speed", 2.5))
        wind_deg = event.get("viento_dominante_direccion", event.get("wind_deg", 45))
        persistencia = event.get("persistencia_dias", 1)
        elite_score = event.get("score_prioridad", event.get("elite_score", 0))
        flujo = event.get("flujo_kgh", 0.01)
        perdida = event.get("perdida_economica_usd_dia", event.get("perdida_total_usd_dia", 0.1))

        # Coerción defensiva — Supabase puede devolver None/strings
        def _f(x, default=0.0):
            try:
                if x is None or x == "":
                    return float(default)
                return float(x)
            except (TypeError, ValueError):
                return float(default)
        ch4_ppb = _f(ch4_ppb, CH4_BACKGROUND_PPB)
        anomaly = _f(anomaly, max(0, ch4_ppb - CH4_BACKGROUND_PPB))
        wind_speed = _f(wind_speed, 2.5)
        wind_deg = _f(wind_deg, 45)
        persistencia = _f(persistencia, 1)
        elite_score = _f(elite_score, 0)
        flujo = _f(flujo, 0.01)
        perdida = _f(perdida, 0.1)

        # Parsear fecha
        fecha_str = event.get("fecha_deteccion", "")
        try:
            fecha = datetime.fromisoformat(fecha_str.replace("Z", "+00:00"))
            hora = fecha.hour
            mes = fecha.month
        except Exception:
            hora = 12
            mes = 4

        # Convertir dirección viento a componentes
        wind_rad = np.radians(wind_deg)
        wind_sin = np.sin(wind_rad)
        wind_cos = np.cos(wind_rad)

        return [
            float(anomaly),
            float(wind_speed),
            float(wind_sin),
            float(wind_cos),
            float(persistencia),
            float(hora),
            float(mes),
            float(elite_score),
            float(flujo),
            float(perdida),
        ]

    def _build_dataset(self) -> Tuple[np.ndarray, np.ndarray, np.ndarray, List[str]]:
        """
        Construye el dataset de entrenamiento desde el historial de eventos.
        Para cada evento, el label de reincidencia es 1 si el mismo activo
        tuvo un evento con elite_score >= ELITE_THRESHOLD en los próximos 7 días.
        """
        if len(self.events) < MIN_EVENTS_FOR_ML:
            return np.array([]), np.array([]), np.array([]), []

        # Ordenar por fecha
        events_sorted = sorted(
            self.events,
            key=lambda e: e.get("fecha_deteccion", ""),
        )

        X = []
        y_class = []  # Reincidencia (0/1)
        y_reg = []    # Elite score futuro estimado
        activos_list = []

        for i, event in enumerate(events_sorted):
            activo = event.get("activo_cercano", "")
            if not activo:
                continue

            features = self._extract_features(event)
            X.append(features)
            activos_list.append(activo)

            # Buscar eventos futuros del mismo activo
            fecha_str = event.get("fecha_deteccion", "")
            try:
                fecha_base = datetime.fromisoformat(fecha_str.replace("Z", "+00:00"))
                if fecha_base.tzinfo is None:
                    fecha_base = fecha_base.replace(tzinfo=timezone.utc)
            except Exception:
                fecha_base = datetime.now(timezone.utc)

            fecha_limite = fecha_base + timedelta(days=REINCIDENCE_DAYS)

            reincide = 0
            max_future_score = 0.0
            for j in range(i + 1, len(events_sorted)):
                ev2 = events_sorted[j]
                if ev2.get("activo_cercano", "") != activo:
                    continue
                fecha2_str = ev2.get("fecha_deteccion", "")
                try:
                    fecha2 = datetime.fromisoformat(fecha2_str.replace("Z", "+00:00"))
                    if fecha2.tzinfo is None:
                        fecha2 = fecha2.replace(tzinfo=timezone.utc)
                except Exception:
                    continue
                if fecha2 > fecha_limite:
                    break
                score2 = ev2.get("score_prioridad", ev2.get("elite_score", 0)) or 0
                try:
                    score2 = float(score2)
                except (TypeError, ValueError):
                    score2 = 0.0
                if score2 >= ELITE_THRESHOLD:
                    reincide = 1
                max_future_score = max(max_future_score, score2)

            y_class.append(reincide)
            y_reg.append(max_future_score)

        if not X:
            return np.array([]), np.array([]), np.array([]), []

        return np.array(X), np.array(y_class), np.array(y_reg), activos_list

    def train(self) -> Dict:
        """
        Entrena los modelos ML con el historial disponible.
        Retorna métricas de entrenamiento.
        """
        if not _SKLEARN_AVAILABLE:
            return {"status": "sklearn_not_available", "method": "statistical"}

        X, y_class, y_reg, activos_list = self._build_dataset()

        if len(X) < MIN_EVENTS_FOR_ML:
            logger.info(f"Datos insuficientes para ML ({len(X)} eventos). Usando análisis estadístico.")
            return {
                "status": "insufficient_data",
                "n_events": len(X),
                "min_required": MIN_EVENTS_FOR_ML,
                "method": "statistical",
            }

        # Normalizar features
        X_scaled = self.scaler.fit_transform(X)

        # ── Clasificador: RandomForest para reincidencia ──────────────────────
        self.rf_classifier = RandomForestClassifier(
            n_estimators=100,
            max_depth=5,
            random_state=42,
            class_weight="balanced",
        )
        self.rf_classifier.fit(X_scaled, y_class)

        # Cross-validation si hay suficientes datos
        cv_scores = []
        if len(X) >= 5:
            cv_scores = cross_val_score(
                self.rf_classifier, X_scaled, y_class, cv=min(5, len(X)), scoring="f1_weighted"
            ).tolist()

        # ── Regresor: GradientBoosting para elite_score futuro ────────────────
        self.gb_regressor = GradientBoostingRegressor(
            n_estimators=100,
            max_depth=3,
            learning_rate=0.1,
            random_state=42,
        )
        self.gb_regressor.fit(X_scaled, y_reg)

        # ── Clustering: KMeans para agrupar activos por patrón ───────────────
        n_clusters = min(4, len(set(activos_list)))
        if n_clusters >= 2:
            self.kmeans = KMeans(n_clusters=n_clusters, random_state=42, n_init=10)
            self.kmeans.fit(X_scaled)

        self._trained = True

        # Importancia de features
        feature_names = [
            "anomaly_ppb", "wind_speed", "wind_sin", "wind_cos",
            "persistencia_dias", "hora", "mes", "elite_score", "flujo_kgh", "perdida_usd"
        ]
        importances = dict(zip(
            feature_names,
            [round(v, 4) for v in self.rf_classifier.feature_importances_]
        ))

        result = {
            "status": "trained",
            "n_events": len(X),
            "n_reincidencias": int(y_class.sum()),
            "cv_f1_scores": [round(s, 4) for s in cv_scores],
            "cv_f1_mean": round(float(np.mean(cv_scores)), 4) if cv_scores else None,
            "feature_importances": importances,
            "n_clusters": n_clusters if n_clusters >= 2 else 0,
            "method": "sklearn_randomforest",
        }

        logger.info(f"Modelos ML entrenados: {result}")
        return result

    def predict_reincidence(self, activo: str, current_event: Dict) -> Dict:
        """
        Predice la probabilidad de reincidencia para un activo dado.
        Retorna probabilidad, score futuro estimado y cluster.
        """
        features = self._extract_features(current_event)
        X = np.array([features])

        if _SKLEARN_AVAILABLE and self._trained and self.rf_classifier is not None:
            X_scaled = self.scaler.transform(X)

            # Probabilidad de reincidencia
            proba = self.rf_classifier.predict_proba(X_scaled)[0]
            # Si solo hay una clase en el entrenamiento, usar fallback estadístico
            if len(proba) < 2:
                return self._statistical_prediction(activo, current_event)
            prob_reincidence = float(proba[1])

            # Score futuro estimado
            future_score = float(max(0, self.gb_regressor.predict(X_scaled)[0]))

            # Cluster
            cluster = int(self.kmeans.predict(X_scaled)[0]) if self.kmeans else -1

            # Nivel de riesgo
            if prob_reincidence >= 0.7:
                risk_level = "ALTO"
                risk_color = "red"
            elif prob_reincidence >= 0.4:
                risk_level = "MEDIO"
                risk_color = "orange"
            else:
                risk_level = "BAJO"
                risk_color = "green"

            return {
                "activo": activo,
                "prob_reincidencia": round(prob_reincidence, 4),
                "elite_score_futuro_estimado": round(future_score, 1),
                "cluster_comportamiento": cluster,
                "nivel_riesgo": risk_level,
                "color_riesgo": risk_color,
                "metodo": "sklearn_ml",
                "ventana_prediccion_dias": REINCIDENCE_DAYS,
            }
        else:
            # Análisis estadístico de fallback
            return self._statistical_prediction(activo, current_event)

    def _statistical_prediction(self, activo: str, current_event: Dict) -> Dict:
        """Predicción estadística simple cuando sklearn no está disponible."""
        # Calcular frecuencia histórica del activo
        activo_events = [e for e in self.events if e.get("activo_cercano", "") == activo]
        n_events = len(activo_events)

        if n_events == 0:
            prob = 0.1
        else:
            # Frecuencia de eventos con score alto
            high_score = sum(
                1 for e in activo_events
                if e.get("score_prioridad", e.get("elite_score", 0)) >= ELITE_THRESHOLD
            )
            prob = min(0.95, (high_score + 1) / (n_events + 2))  # Suavizado de Laplace

        anomaly = current_event.get("ch4_ppb_anomaly", 0)
        future_score = min(120, prob * 80 + anomaly * 0.1)

        if prob >= 0.6:
            risk_level = "ALTO"
            risk_color = "red"
        elif prob >= 0.3:
            risk_level = "MEDIO"
            risk_color = "orange"
        else:
            risk_level = "BAJO"
            risk_color = "green"

        return {
            "activo": activo,
            "prob_reincidencia": round(prob, 4),
            "elite_score_futuro_estimado": round(future_score, 1),
            "cluster_comportamiento": -1,
            "nivel_riesgo": risk_level,
            "color_riesgo": risk_color,
            "metodo": "estadistico_laplace",
            "ventana_prediccion_dias": REINCIDENCE_DAYS,
            "n_eventos_historicos": n_events,
        }

    def analyze_all_assets(self, current_detections: List[Dict]) -> List[Dict]:
        """
        Analiza todos los activos con detecciones actuales.
        Retorna lista ordenada por probabilidad de reincidencia (mayor primero).
        """
        # Entrenar si no está entrenado
        if not self._trained:
            self.train()

        results = []
        for detection in current_detections:
            activo = detection.get("activo_cercano", detection.get("activo", ""))
            if not activo:
                continue
            prediction = self.predict_reincidence(activo, detection)
            # Agregar datos del evento actual
            prediction["ch4_ppb_actual"] = detection.get(
                "intensidad_ppb", detection.get("ch4_ppb_total", 0)
            )
            prediction["elite_score_actual"] = detection.get(
                "score_prioridad", detection.get("elite_score", 0)
            )
            prediction["categoria_actual"] = detection.get("categoria_alerta", "")
            results.append(prediction)

        # Ordenar por probabilidad de reincidencia
        results.sort(key=lambda x: x["prob_reincidencia"], reverse=True)
        return results

    def generate_ml_report(self, current_detections: List[Dict]) -> Dict:
        """
        Genera reporte completo de análisis ML para el ciclo actual.
        """
        timestamp = datetime.now(timezone.utc).isoformat()

        # Entrenar modelos
        training_result = self.train()

        # Analizar activos
        asset_predictions = self.analyze_all_assets(current_detections)

        # Estadísticas globales
        high_risk = [p for p in asset_predictions if p["nivel_riesgo"] == "ALTO"]
        medium_risk = [p for p in asset_predictions if p["nivel_riesgo"] == "MEDIO"]
        low_risk = [p for p in asset_predictions if p["nivel_riesgo"] == "BAJO"]

        # Activo más crítico
        top_asset = asset_predictions[0] if asset_predictions else None

        report = {
            "version": "3.7",
            "timestamp": timestamp,
            "modelo": training_result,
            "resumen": {
                "total_activos_analizados": len(asset_predictions),
                "activos_riesgo_alto": len(high_risk),
                "activos_riesgo_medio": len(medium_risk),
                "activos_riesgo_bajo": len(low_risk),
                "activo_mas_critico": top_asset["activo"] if top_asset else None,
                "prob_reincidencia_maxima": top_asset["prob_reincidencia"] if top_asset else 0,
            },
            "predicciones_por_activo": asset_predictions,
            "recomendaciones": self._generate_recommendations(asset_predictions),
        }

        # Guardar reporte
        report_path = os.path.join(
            self.data_dir,
            f"ml_report_{datetime.now(timezone.utc).strftime('%Y%m%d_%H%M%S')}.json"
        )
        try:
            with open(report_path, "w") as f:
                json.dump(report, f, indent=2, ensure_ascii=False)
            logger.info(f"Reporte ML guardado: {report_path}")
        except Exception as e:
            logger.warning(f"Error guardando reporte ML: {e}")

        return report

    def _generate_recommendations(self, predictions: List[Dict]) -> List[Dict]:
        """Genera recomendaciones de intervención basadas en las predicciones ML."""
        recommendations = []
        for pred in predictions:
            if pred["nivel_riesgo"] == "ALTO":
                recommendations.append({
                    "activo": pred["activo"],
                    "prioridad": 1,
                    "accion": "INTERVENCIÓN INMEDIATA",
                    "descripcion": (
                        f"Probabilidad de reincidencia {pred['prob_reincidencia']*100:.1f}% "
                        f"en próximos {REINCIDENCE_DAYS} días. "
                        f"Elite Score futuro estimado: {pred['elite_score_futuro_estimado']:.1f}. "
                        "Desplegar equipo de campo para inspección y reparación."
                    ),
                    "urgencia_horas": 24,
                })
            elif pred["nivel_riesgo"] == "MEDIO":
                recommendations.append({
                    "activo": pred["activo"],
                    "prioridad": 2,
                    "accion": "MONITOREO INTENSIVO",
                    "descripcion": (
                        f"Probabilidad de reincidencia {pred['prob_reincidencia']*100:.1f}%. "
                        "Aumentar frecuencia de monitoreo a cada 1 hora. "
                        "Preparar equipo de campo para posible intervención."
                    ),
                    "urgencia_horas": 72,
                })
        return recommendations


# ─── Instancia global ─────────────────────────────────────────────────────────
ml_analyzer = MLPersistenceAnalyzer()


if __name__ == "__main__":
    import sys
    logging.basicConfig(level=logging.INFO)

    print("=== MetanoSRGAN Elite v3.7 — Análisis ML de Persistencia ===")
    print(f"scikit-learn disponible: {_SKLEARN_AVAILABLE}")

    # Cargar datos reales
    data_path = "/home/ubuntu/metanosrgan_v37/data/event_master_table.json"
    if os.path.exists(data_path):
        with open(data_path) as f:
            events = json.load(f)
        print(f"Eventos históricos cargados: {len(events)}")

        # Entrenar
        training = ml_analyzer.train()
        print(f"Entrenamiento: {training}")

        # Generar reporte
        report = ml_analyzer.generate_ml_report(events)
        print(f"\nReporte ML generado:")
        print(f"  Activos analizados: {report['resumen']['total_activos_analizados']}")
        print(f"  Riesgo ALTO: {report['resumen']['activos_riesgo_alto']}")
        print(f"  Riesgo MEDIO: {report['resumen']['activos_riesgo_medio']}")
        print(f"  Activo más crítico: {report['resumen']['activo_mas_critico']}")
        print(f"\nPredicciones:")
        for pred in report["predicciones_por_activo"]:
            print(
                f"  {pred['activo']:20s} | Reincidencia: {pred['prob_reincidencia']*100:5.1f}% "
                f"| Riesgo: {pred['nivel_riesgo']:6s} | Score futuro: {pred['elite_score_futuro_estimado']:5.1f}"
            )
    else:
        print(f"No se encontró {data_path}")
        sys.exit(1)
